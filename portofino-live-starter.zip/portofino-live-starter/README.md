# Portofino Live

Portofino Live è una web app PWA per Portofino, pensata per raccogliere in un’unica piattaforma:

- eventi
- luoghi iconici
- attività locali
- servizi utili
- mappa interattiva
- area admin con gestione contenuti
- media library con immagini riutilizzabili

Lo stack scelto è:

- **Next.js App Router**
- **TypeScript**
- **Tailwind CSS**
- **Supabase** (database, auth, storage)
- **Mapbox** (mappa interattiva)
- **Vercel** (deploy)

---

## Funzionalità principali

### Pubblico
- Home elegante con hero
- Elenco eventi
- Elenco luoghi
- Elenco attività locali
- Elenco servizi utili
- Mappa interattiva con filtri
- Pagine dettaglio
- SEO base
- PWA installabile

### Admin
- Login protetto con Supabase Auth
- Dashboard admin
- CRUD eventi
- CRUD luoghi
- CRUD attività
- CRUD servizi
- Upload immagini
- Media library
- Selezione immagini già caricate
- Gestione partner per la propria attività

---

## Requisiti

Prima di iniziare assicurati di avere:

- Node.js 20+
- npm
- account Supabase
- account Mapbox
- account Vercel
- repository GitHub

---

## Setup progetto

### 1. Clona o crea il progetto

```bash
npx create-next-app@latest portofino-live --typescript --tailwind --eslint --app --src-dir --import-alias "@/*"
cd portofino-live
```

### 2. Installa dipendenze

```bash
npm install @supabase/supabase-js @supabase/ssr clsx lucide-react mapbox-gl
npm install -D @types/mapbox-gl
```

---

## Variabili ambiente

Crea il file `.env.local`:

```env
NEXT_PUBLIC_SITE_URL=http://localhost:3000
NEXT_PUBLIC_SUPABASE_URL=https://TUO-PROGETTO.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=LA_TUA_ANON_KEY
NEXT_PUBLIC_MAPBOX_TOKEN=LA_TUA_MAPBOX_PUBLIC_TOKEN
```

---

## Setup Supabase

### 1. Crea un nuovo progetto Supabase

Dal dashboard Supabase crea un nuovo progetto.

### 2. Esegui lo schema SQL

Apri:

- Supabase Dashboard
- SQL Editor

Incolla lo **schema SQL completo** del progetto.

### 3. Crea il bucket Storage

Vai su:

- Storage
- New bucket

Crea il bucket:

```txt
media
```

### 4. Esegui il seed iniziale

Nel SQL Editor incolla il **seed iniziale Portofino** per popolare:
- places
- businesses
- services
- events
- announcements

### 5. Crea utente admin

Vai su:

- Authentication
- Users
- Create user

Crea email e password per l’admin.

### 6. Promuovi a superadmin

Nel SQL Editor:

```sql
update public.profiles
set role = 'superadmin'
where email = 'admin@portofinolive.it';
```

---

## Avvio locale

```bash
npm run dev
```

Apri:

```txt
http://localhost:3000
```

---

## Struttura del progetto

```txt
src/
├─ app/
│  ├─ admin/
│  ├─ attivita/
│  ├─ eventi/
│  ├─ luoghi/
│  ├─ mappa/
│  ├─ servizi/
│  ├─ globals.css
│  ├─ layout.tsx
│  ├─ manifest.ts
│  ├─ page.tsx
│  ├─ robots.ts
│  └─ sitemap.ts
├─ components/
│  ├─ admin/
│  ├─ cards/
│  ├─ layout/
│  ├─ map/
│  ├─ pwa/
│  └─ shared/
├─ lib/
│  ├─ supabase/
│  ├─ auth.ts
│  ├─ queries.ts
│  ├─ media.ts
│  ├─ categories.ts
│  ├─ types.ts
│  └─ utils.ts
├─ middleware.ts
public/
├─ icons/
├─ images/
├─ og-image.jpg
└─ sw.js
```

---

## Rotte principali

### Pubbliche
- `/`
- `/eventi`
- `/eventi/[slug]`
- `/luoghi`
- `/luoghi/[slug]`
- `/attivita`
- `/attivita/[slug]`
- `/servizi`
- `/mappa`

### Admin
- `/admin/login`
- `/admin`
- `/admin/eventi`
- `/admin/luoghi`
- `/admin/attivita`
- `/admin/servizi`
- `/admin/media`

---

## Ruoli

### superadmin
- accesso completo
- gestione utenti e contenuti

### editor
- gestione eventi
- gestione luoghi
- gestione attività
- gestione servizi
- gestione media

### partner
- accesso alla propria attività
- modifica della propria scheda

---

## Storage immagini

Le immagini vengono caricate nel bucket:

```txt
media
```

Ogni immagine:
- viene salvata in Supabase Storage
- viene registrata nella tabella `media_assets`
- può essere riutilizzata nei form tramite media library

---

## Mappa

La mappa usa **Mapbox** con:
- marker da `map_points`
- filtri per `place`, `business`, `service`
- card dettaglio laterale
- geolocalizzazione utente

Per farla funzionare serve:

```env
NEXT_PUBLIC_MAPBOX_TOKEN=...
```

---

## SEO e PWA

Sono inclusi:
- metadata globali
- metadata dinamici sulle pagine dettaglio
- `robots.ts`
- `sitemap.ts`
- `manifest.ts`
- `sw.js`
- icone app
- open graph image

File da avere in `public/`:
- `og-image.jpg`
- `images/hero-portofino.jpg`

File da avere in `public/icons/`:
- `icon-192.png`
- `icon-512.png`
- `apple-icon.png`

---

## Test da fare prima del deploy

### Pubblico
- [ ] homepage caricata
- [ ] eventi visibili
- [ ] luoghi visibili
- [ ] attività visibili
- [ ] servizi visibili
- [ ] mappa funzionante

### Admin
- [ ] login admin
- [ ] dashboard admin
- [ ] creazione evento
- [ ] modifica luogo
- [ ] creazione attività
- [ ] creazione servizio
- [ ] upload immagine
- [ ] selezione immagine da media library
- [ ] eliminazione media

### SEO/PWA
- [ ] `/robots.txt`
- [ ] `/sitemap.xml`
- [ ] manifest accessibile
- [ ] icona app caricata
- [ ] service worker registrato

---

## Deploy su Vercel

### 1. Push su GitHub

```bash
git init
git add .
git commit -m "Initial Portofino Live"
git branch -M main
git remote add origin <URL_REPOSITORY>
git push -u origin main
```

### 2. Importa su Vercel
- Vai su Vercel
- Import repository
- Seleziona il progetto

### 3. Aggiungi environment variables
Nel progetto Vercel aggiungi:

- `NEXT_PUBLIC_SITE_URL`
- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`
- `NEXT_PUBLIC_MAPBOX_TOKEN`

### 4. Deploy
Lancia il deploy.

### 5. Collega il dominio
Esempi:
- `portofinolive.it`
- `portofinolive.app`

---

## Query SQL utili

### Elenco profili
```sql
select id, email, role, is_active
from public.profiles
order by created_at desc;
```

### Eventi pubblicati
```sql
select title, slug, published
from public.events
order by start_at asc;
```

### Luoghi pubblicati
```sql
select title, slug, published
from public.places
order by sort_order asc;
```

### Attività pubblicate
```sql
select title, slug, published
from public.businesses
order by sort_order asc;
```

### Servizi pubblicati
```sql
select title, slug, published
from public.services
order by sort_order asc;
```

### Punti mappa
```sql
select *
from public.map_points
where published = true
and latitude is not null
and longitude is not null;
```

---

## Migliorie future consigliate

### V2
- notifiche push
- ricerca globale
- filtri avanzati
- dettagli servizi dedicati
- dashboard analytics
- gestione utenti admin da pannello

### V3
- prenotazioni
- offerte partner
- itinerari personalizzati
- contenuti multilingua
- ticketing eventi

---

## Stato del progetto

Portofino Live è impostato come **V1 completa**, con:
- backend strutturato
- admin funzionante
- contenuti gestibili
- immagini riusabili
- mappa interattiva
- SEO e PWA pronti
- percorso di deploy definito

---

## Note finali

Prima di presentare il progetto a partner, Comune o attività locali conviene:
- sostituire immagini temporanee
- verificare testi demo
- sostituire link fittizi
- caricare almeno 10 luoghi reali
- caricare almeno 10 attività reali
- caricare almeno 8 servizi reali
- caricare almeno 5 eventi reali
