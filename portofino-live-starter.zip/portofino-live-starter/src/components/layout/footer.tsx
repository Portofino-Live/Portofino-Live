export function Footer() {
  return (
    <footer className="border-t py-8">
      <div className="container-page text-sm text-slate-600">
        © {new Date().getFullYear()} Portofino Live
      </div>
    </footer>
  )
}
