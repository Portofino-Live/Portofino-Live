import Link from 'next/link'

export function Header() {
  return (
    <header className="sticky top-0 z-50 border-b bg-white/80 backdrop-blur-xl">
      <div className="container-page flex h-16 items-center justify-between">
        <Link href="/" className="text-xl font-bold tracking-tight">
          Portofino Live
        </Link>
        <nav className="hidden gap-6 md:flex">
          <Link href="/luoghi" className="text-sm font-medium">Luoghi</Link>
          <Link href="/eventi" className="text-sm font-medium">Eventi</Link>
          <Link href="/attivita" className="text-sm font-medium">Attività</Link>
          <Link href="/servizi" className="text-sm font-medium">Servizi</Link>
          <Link href="/mappa" className="text-sm font-medium">Mappa</Link>
        </nav>
      </div>
    </header>
  )
}
