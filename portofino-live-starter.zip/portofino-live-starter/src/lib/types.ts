export type MapPoint = {
  source_type: 'place' | 'business' | 'service'
  id: string
  title: string
  slug: string
  category_name: string | null
  address: string | null
  latitude: number | null
  longitude: number | null
  cover_image: string | null
  featured: boolean
  published: boolean
}
