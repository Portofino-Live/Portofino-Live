export default async function Page() {
  return (
    <section className="section-space">
      <div className="container-page">
        <h1 className="text-3xl font-bold">Dettaglio evento</h1>
        <p className="mt-3 text-slate-600">Struttura pronta per slug dinamico.</p>
      </div>
    </section>
  )
}
