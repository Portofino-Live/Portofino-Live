import './globals.css'
import type { Metadata } from 'next'
import { Header } from '@/components/layout/header'
import { Footer } from '@/components/layout/footer'
import { RegisterSW } from '@/components/pwa/register-sw'

export const metadata: Metadata = {
  title: 'Portofino Live',
  description: 'Eventi, luoghi, attività locali e servizi utili di Portofino.',
}

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="it">
      <body>
        <RegisterSW />
        <Header />
        <main className="min-h-screen">{children}</main>
        <Footer />
      </body>
    </html>
  )
}
