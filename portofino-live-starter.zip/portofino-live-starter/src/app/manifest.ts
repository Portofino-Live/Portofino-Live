import type { MetadataRoute } from 'next'

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: 'Portofino Live',
    short_name: 'Portofino Live',
    description: 'Eventi, luoghi iconici, attività locali e servizi utili di Portofino.',
    start_url: '/',
    display: 'standalone',
    background_color: '#fcfcfa',
    theme_color: '#0f172a',
    lang: 'it-IT',
    icons: [
      { src: '/icons/icon-192.png', sizes: '192x192', type: 'image/png' },
      { src: '/icons/icon-512.png', sizes: '512x512', type: 'image/png' }
    ],
  }
}
