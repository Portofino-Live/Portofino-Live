export default function Page() {
  return (
    <section className="section-space">
      <div className="container-page">
        <h1 className="text-3xl font-bold">Attività</h1>
        <p className="mt-3 text-slate-600">Pagina base pronta da collegare ai dati reali.</p>
      </div>
    </section>
  )
}
