import Link from 'next/link'

export default function HomePage() {
  return (
    <section className="section-space">
      <div className="container-page">
        <p className="section-eyebrow">Portofino Live</p>
        <h1 className="text-4xl font-bold tracking-tight md:text-6xl">
          Starter kit del progetto
        </h1>
        <p className="mt-6 max-w-2xl text-lg text-slate-600">
          Questa è la base iniziale del progetto Portofino Live. Da qui puoi collegare
          Supabase, Mapbox, media library e pannello admin.
        </p>
        <div className="mt-8 flex flex-wrap gap-4">
          <Link href="/eventi" className="btn-primary">Eventi</Link>
          <Link href="/mappa" className="btn-secondary">Mappa</Link>
        </div>
      </div>
    </section>
  )
}
