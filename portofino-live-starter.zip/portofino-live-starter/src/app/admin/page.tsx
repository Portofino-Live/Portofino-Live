export default function AdminPage() {
  return (
    <section className="section-space">
      <div className="container-page">
        <h1 className="text-3xl font-bold">Dashboard Admin</h1>
        <p className="mt-3 text-slate-600">Base pronta per collegare auth e CRUD.</p>
      </div>
    </section>
  )
}
