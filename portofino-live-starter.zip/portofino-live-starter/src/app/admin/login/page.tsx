export default function AdminLoginPage() {
  return (
    <section className="section-space">
      <div className="container-page max-w-md">
        <div className="rounded-3xl border bg-white p-8 shadow-sm">
          <h1 className="text-3xl font-bold">Login Admin</h1>
          <p className="mt-3 text-slate-600">Collega qui Supabase Auth.</p>
        </div>
      </div>
    </section>
  )
}
