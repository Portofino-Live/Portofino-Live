const CACHE_NAME = 'portofino-live-v1'
const urlsToCache = ['/', '/eventi', '/luoghi', '/attivita', '/servizi', '/mappa']

self.addEventListener('install', (event) => {
  event.waitUntil(caches.open(CACHE_NAME).then((cache) => cache.addAll(urlsToCache)))
})

self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') return

  event.respondWith(
    caches.match(event.request).then((cached) => cached || fetch(event.request))
  )
})
